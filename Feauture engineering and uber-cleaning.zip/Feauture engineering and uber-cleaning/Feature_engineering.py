import pandas as pd

# Load the cleaned dataset
df = pd.read_csv("cleaned_uber.csv")

# Convert pickup_datetime to datetime (in case it’s still a string)
df['pickup_datetime'] = pd.to_datetime(df['pickup_datetime'])

# Add new features
df['hour'] = df['pickup_datetime'].dt.hour
df['day'] = df['pickup_datetime'].dt.day
df['month'] = df['pickup_datetime'].dt.month
df['weekday'] = df['pickup_datetime'].dt.day_name()

# Add peak time indicator (7-9 AM or 5-7 PM)
df['is_peak'] = df['hour'].apply(lambda h: 'Peak' if (7 <= h <= 9 or 17 <= h <= 19) else 'Off-Peak')

# Show some of the new features
print(df[['pickup_datetime', 'hour', 'weekday', 'is_peak']].head())

# Save the enhanced dataset
df.to_csv("enhanced_uber.csv", index=False)
print("\n✅ Enhanced dataset saved as enhanced_uber.csv")

