import pandas as pd

# 1. Load the dataset
df = pd.read_csv("uber.csv")

# 2. View basic info
print("✅ Preview of dataset:")
print(df.head())

print("\n✅ Structure:")
print(df.info())

# 3. Check for missing values
print("\n✅ Missing values in each column:")
print(df.isnull().sum())

# 4. Drop rows with missing values
df = df.dropna()

# 5. Drop duplicates (if any)
df = df.drop_duplicates()

# 6. Convert 'pickup_datetime' to datetime format (if it exists)
if 'pickup_datetime' in df.columns:
    df['pickup_datetime'] = pd.to_datetime(df['pickup_datetime'])

# 7. Final check
print("\n✅ Cleaned data summary:")
print(df.describe())
print("\n✅ Data shape after cleaning:", df.shape)

# 8. Export to a new CSV file for Power BI
df.to_csv("cleaned_uber.csv", index=False)
print("\n✅ Cleaned dataset saved as cleaned_uber.csv")
